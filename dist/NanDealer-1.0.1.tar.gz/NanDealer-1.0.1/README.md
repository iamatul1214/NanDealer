# NanDealer 
This library takes your dataframe with Nan values and performs the functions to deal with nan values, and then returns the dataframe with only numerical columns. For input it can take data frame with categorical columns as well, and in output only numerical columns will be returned.

## Installation
pip install NanDealer

## How to use it?


## License


